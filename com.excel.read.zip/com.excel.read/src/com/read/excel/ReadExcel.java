package com.read.excel;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
public class ReadExcel {
 public static void search(File file,Object name)
 {
  File[] list = file.listFiles();
  for (File fil : list)
             {
                            if (fil.isDirectory()){
                             search(fil,name);
                            }
                 if(fil.isFile())
                  if(fil.getName().equals(name)) {
                  System.out.println("File Found "+fil.getName()+" at path "+fil.getParent());
             } 
}
 }
  public static void main(String args[]) throws IOException {
                File file1 = new File("C:\\users\\GA331852\\workspace");
                ArrayList<employee> list = new ArrayList<employee>();
                FileInputStream file = new FileInputStream(new File("updateddata1.xls"));
                HSSFWorkbook workbook = new HSSFWorkbook(file);
                HSSFSheet sheet = workbook.getSheetAt(0);
                Iterator<Row> rowIterator = sheet.iterator();
                //employee emp=new employee();
                rowIterator.next();
                while (rowIterator.hasNext()) 
                {        
                	employee emp=new employee();
                     Row row = rowIterator.next();
                     Iterator<Cell> cellIterator = row.cellIterator();
//                      while (cellIterator.hasNext()) 
//                          {
                            Cell cell = cellIterator.next();
                            System.out.println(cell.getStringCellValue());
                                emp.setId(cell.getStringCellValue());
                                cell = cellIterator.next();
                                System.out.println(cell.getStringCellValue());
                                emp.setName(cell.getStringCellValue());
                                cell = cellIterator.next();
                                System.out.println(cell.getStringCellValue());
                                emp.setAddress(cell.getStringCellValue());
                                cell = cellIterator.next();
                                System.out.println(cell.getNumericCellValue());
                                emp.setSalary(cell.getNumericCellValue());
//                                 }
                                list.add(emp);
                }
                Iterator i=list.iterator();
                while(i.hasNext()){
                	employee employee=new employee();
                	employee=(employee) i.next();
                	System.out.println(employee.getId()+" "+employee.getName()+" "+employee.getAddress()+" "+employee.getSalary());
                	
                	
                //search(file1,i.next());
      }
  }
  }
